package HomeWorks.day3HomeWork;

public interface ComparableById {
    boolean compareById(int id);
}
