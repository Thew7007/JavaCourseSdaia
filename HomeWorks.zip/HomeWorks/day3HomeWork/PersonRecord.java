package HomeWorks.day3HomeWork;

public abstract class PersonRecord {
    public abstract String getDetails();

}
