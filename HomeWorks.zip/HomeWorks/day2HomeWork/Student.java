package HomeWorks.day2HomeWork;

public class Student {
    private String name;
    private int id;

    // Constructor to initialize attributes
    public Student(String name, int id) {
        this.name = name;
        this.id = id;
    }

    // Getter for name
    public String getName() {
        return name;
    }

    // Getter for id
    public int getId() {
        return id;
    }
}

